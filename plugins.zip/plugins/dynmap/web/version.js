var dynmapversion = "2.5-Dev201706100401";

